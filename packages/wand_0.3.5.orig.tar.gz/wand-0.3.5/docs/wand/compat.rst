
.. automodule:: wand.compat
   :members:
