
.. automodule:: wand.color
   :members:

