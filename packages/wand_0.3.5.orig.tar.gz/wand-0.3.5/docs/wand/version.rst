
.. automodule:: wand.version
   :members:

