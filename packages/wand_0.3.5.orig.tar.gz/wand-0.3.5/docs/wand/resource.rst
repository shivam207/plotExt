
.. automodule:: wand.resource
   :members:

