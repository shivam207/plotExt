
.. automodule:: wand.sequence
   :members:
