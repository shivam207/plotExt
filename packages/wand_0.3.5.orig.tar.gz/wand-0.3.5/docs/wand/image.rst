
.. automodule:: wand.image
   :members:

