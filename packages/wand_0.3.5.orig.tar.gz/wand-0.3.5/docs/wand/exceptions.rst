
.. automodule:: wand.exceptions
   :members:
   :show-inheritance:

