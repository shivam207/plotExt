Talks and Presentations
=======================

Talks in 2012
-------------

- `Lightning talk at Python Korea November 2012`__

__ http://j.mp/pykr2012-wand
