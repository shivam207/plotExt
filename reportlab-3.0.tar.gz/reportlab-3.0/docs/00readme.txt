Thid directory holds documentation.  For end users,
it should contain a number of PDF manuals.  For
people working with the source, this directory will
be the destination for any manuals built.

If you don't see the pdf manual you expected or you wich to
ensure an up to date copy run the script tools/genAll.py!
